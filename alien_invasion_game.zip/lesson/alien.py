import random
import pygame
from pygame.sprite import Sprite


class Alien(Sprite):
    """Yuxarıdan ekrana daxil olan yadplanetlini təmsil edən sinif."""

    def __init__(self, ai_settings, screen, image_path):
        """Yadplanetlini, şəklini və təsadüfi üst mövqeyini təyin edir."""
        super().__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        raw_image = pygame.image.load(image_path).convert()
        self.image = pygame.transform.smoothscale(raw_image, (54, 54))
        self.rect = self.image.get_rect()

        # Ekranın yuxarı kənarında təsadüfi X mövqeyində başlayır
        max_x = max(0, ai_settings.screen_width - self.rect.width)
        self.rect.x = random.randint(0, max_x)
        self.rect.bottom = 0

        self.x = float(self.rect.x)
        self.y = float(self.rect.y)

        # Yüngül üfüqi istiqamət (-1 və ya 1)
        self.sway_dir = random.choice([-1, 1])

    def update(self):
        """Yadplanetlini aşağı və yüngül sağ-sol hərəkət etdirir."""
        self.y += self.ai_settings.alien_speed_y
        self.rect.y = int(self.y)

        self.x += self.ai_settings.alien_sway_speed * self.sway_dir
        if self.x <= 0:
            self.x = 0
            self.sway_dir = 1
        elif self.x + self.rect.width >= self.ai_settings.screen_width:
            self.x = self.ai_settings.screen_width - self.rect.width
            self.sway_dir = -1

        self.rect.x = int(self.x)

    def blitme(self):
        """Yadplanetlini ekranda çəkir."""
        self.screen.blit(self.image, self.rect)